function botaoQuero(x) {
  x.classList.toggle("selecionado");
}
